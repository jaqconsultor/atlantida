<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost:8189"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "empleados";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

$sqlEmpleaados = mysqli_query($conexionBD,"SELECT * FROM empleados WHERE id = ".$_GET["id"]);
if(mysqli_num_rows($sqlEmpleaados) > 0){
	$empleaados = mysqli_fetch_all($sqlEmpleaados,MYSQLI_ASSOC);
	echo json_encode($empleaados);
	exit();
}
else{  echo json_encode(["success"=>0]); }

?>
