<?php
// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost:8189"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "aulascur_sos";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);
?>
