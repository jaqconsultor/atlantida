<?php
include('cabecera.php');
include('config.php');

$data = json_decode(file_get_contents("php://input"));

$id=$_GET["id"];

$Estado=2;   

$sqlEmpleaados = mysqli_query($conexionBD,"UPDATE contratos SET Estado='$Estado' WHERE id='$id'");
echo json_encode(["success"=>1]);
exit();

?>
